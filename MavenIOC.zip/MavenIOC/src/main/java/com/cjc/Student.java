package com.cjc;

public class Student {

	
	public Student() {
		System.out.println("Hello I Am Aditya");
	}
}
